package com.example.studybuddyapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
