import 'package:flutter/material.dart';

//Color custom_green = Color(0xff18DAA3);
Color custom_green = const Color.fromRGBO(124, 77, 255, 1);
Color backgroundColors = Colors.white;
